
// Clase Eventos.
class EventEmitter {
	
	constructor() {
		this.listeners={};
	}

	emit(nomEvento, ...params){
		if(this.listeners[nomEvento]){
			this.listeners[nomEvento].forEach(cb => cb(...params));
		}
	}

	on(nomEvento, cb){
		this.listeners[nomEvento] = this.listeners[nomEvento] || [];
		this.listeners[nomEvento].push(cb);
	}
	}


exports = module.exports = EventEmitter;

